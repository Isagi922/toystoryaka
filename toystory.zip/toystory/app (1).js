const data = {
  g1: [
    { e: "🐻", n: "Brown Teddy Bear",  p: "$14.99", o: "$19.99" },
    { e: "🐨", n: "Koala Plush",       p: "$12.99", o: null },
    { e: "🐰", n: "Baby Bunny Doll",   p: "$10.99", o: "$14.99" },
    { e: "🦁", n: "Lion King Plush",   p: "$16.99", o: null },
  ],
  g2: [
    { e: "🟫", n: "Stacking Blocks",   p: "$9.99",  o: "$13.99" },
    { e: "🧩", n: "Wooden Puzzle",     p: "$11.99", o: null },
    { e: "🚂", n: "Mini Train Set",    p: "$18.99", o: "$24.99" },
    { e: "🔢", n: "Abacus Toy",        p: "$8.99",  o: null },
  ],
  g3: [
    { e: "🧸", n: "Big Teddy Bear",    p: "$29.99", o: null },
    { e: "🦸‍♂️", n: "Captain Figure", p: "$22.99", o: "$27.99" },
    { e: "👨‍🍳", n: "Chef Doll Set",  p: "$19.99", o: null },
    { e: "🏎️", n: "Race Car Toy",     p: "$15.99", o: "$19.99" },
  ],
};

let cart = 0;
const badge = document.getElementById("badge");

// Render product cards
Object.entries(data).forEach(([id, items]) => {
  document.getElementById(id).innerHTML = items.map(i => `
    <div class="bg-gray-50 rounded-2xl p-4 cursor-pointer hover:shadow-lg transition-shadow">
      <div class="bg-white rounded-xl h-28 flex items-center justify-center text-6xl mb-3 select-none">${i.e}</div>
      <p class="text-sm font-bold text-gray-700 mb-1">${i.n}</p>
      <p class="font-black text-yellow-400 mb-2">${i.p}${i.o ? `<span class="text-xs text-gray-400 line-through font-semibold ml-1">${i.o}</span>` : ""}</p>
      <button class="add-btn w-full bg-yellow-400 text-gray-900 font-black text-sm py-2 rounded-xl border-0 cursor-pointer hover:bg-yellow-500 transition-colors">Add to Cart</button>
    </div>
  `).join("");
});

// Cart buttons
document.querySelectorAll(".add-btn").forEach(btn => {
  btn.addEventListener("click", function () {
    badge.textContent = ++cart;
    this.textContent = "Added ✓";
    this.classList.replace("bg-yellow-400", "bg-green-500");
    this.classList.add("text-white");
    setTimeout(() => {
      this.textContent = "Add to Cart";
      this.classList.replace("bg-green-500", "bg-yellow-400");
      this.classList.remove("text-white");
    }, 1400);
  });
});
